package com.example.assignment7;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TextView tvMainDescription, tvClassDescription, tvClassList;
    EditText etClassInput;
    Button btnLogo;
    ArrayList<String> classList = new ArrayList<String>();
    ArrayList<String> classDescriptions = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvMainDescription = findViewById(R.id.tvMainDescription);
        tvClassDescription = findViewById(R.id.tvClassDescription);
        btnLogo = findViewById(R.id.btnLogo);
        tvClassList = findViewById(R.id.tvClassList);
        etClassInput = findViewById(R.id.etClassInput);

        // populate our class data arrays
        addValuesToClassList();
        addValuesToClassDescriptions();

        tvMainDescription.setText(getString(R.string.mainDescript));
        tvClassList.setText(getString(R.string.sClassList));
        etClassInput.setHint(getString(R.string.sHint));

        tvClassDescription.setVisibility(View.GONE);

        tvClassList.setTextSize(14);
        tvClassList.setMovementMethod(new ScrollingMovementMethod());

        for (int i = 0; i < classList.size(); i++) {
            tvClassList.append(classList.get(i));
            tvClassList.append(getString(R.string.newLine));
        }

        btnLogo.setText(R.string.sLookUp);
        btnLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String classID = etClassInput.getText().toString().trim();
                String classRow;
                int classFoundInRow;
                int indexOfClass = 0;
                for (int i = 0; i < classList.size(); i++) {
                    classRow = classList.get(i);
                    classFoundInRow = classRow.indexOf(classID);
                    if (classFoundInRow > 0) {
                        indexOfClass = i;
                        break;
                    }
                }

                tvClassDescription.setText(getString(R.string.classDescription));
                tvClassDescription.append(getString(R.string.newLine));
                tvClassDescription.append(classDescriptions.get(indexOfClass));
                tvClassDescription.setTextSize(14);
                tvClassDescription.setMovementMethod(new ScrollingMovementMethod());
                tvClassDescription.setVisibility(View.VISIBLE);
            }
        });
    }

    private void addValuesToClassList() {
        classList.add(getString(R.string.classList0));
        classList.add(getString(R.string.classList1));
        classList.add(getString(R.string.classList2));
        classList.add(getString(R.string.classList3));
        classList.add(getString(R.string.classList4));
        classList.add(getString(R.string.classList5));
        classList.add(getString(R.string.classList6));
        classList.add(getString(R.string.classList7));
        classList.add(getString(R.string.classList8));
        classList.add(getString(R.string.classList9));
        classList.add(getString(R.string.classList10));
        classList.add(getString(R.string.classList11));
        classList.add(getString(R.string.classList12));
        classList.add(getString(R.string.classList13));
        classList.add(getString(R.string.classList14));
        classList.add(getString(R.string.classList15));
        classList.add(getString(R.string.classList16));
        classList.add(getString(R.string.classList17));
        classList.add(getString(R.string.classList18));
    }

    private void addValuesToClassDescriptions() {
        classDescriptions.add(getString(R.string.classDescript0));
        classDescriptions.add(getString(R.string.classDescript1));
        classDescriptions.add(getString(R.string.classDescript2));
        classDescriptions.add(getString(R.string.classDescript3));
        classDescriptions.add(getString(R.string.classDescript4));
        classDescriptions.add(getString(R.string.classDescript5));
        classDescriptions.add(getString(R.string.classDescript6));
        classDescriptions.add(getString(R.string.classDescript7));
        classDescriptions.add(getString(R.string.classDescript8));
        classDescriptions.add(getString(R.string.classDescript9));
        classDescriptions.add(getString(R.string.classDescript10));
        classDescriptions.add(getString(R.string.classDescript11));
        classDescriptions.add(getString(R.string.classDescript12));
        classDescriptions.add(getString(R.string.classDescript13));
        classDescriptions.add(getString(R.string.classDescript14));
        classDescriptions.add(getString(R.string.classDescript15));
        classDescriptions.add(getString(R.string.classDescript16));
        classDescriptions.add(getString(R.string.classDescript17));
        classDescriptions.add(getString(R.string.classDescript18));
    }
}

